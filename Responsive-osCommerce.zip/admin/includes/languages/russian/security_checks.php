<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Проверка безопасности');

define('TABLE_HEADING_TITLE', 'Заголовок');
define('TABLE_HEADING_MODULE', 'Модуль');
define('TABLE_HEADING_INFO', 'Информация');

