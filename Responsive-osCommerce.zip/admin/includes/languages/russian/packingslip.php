<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_COMMENTS', 'Комментарии');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Код Товара');
define('TABLE_HEADING_PRODUCTS', 'Товары');

define('ENTRY_SOLD_TO', 'ПОКУПАТЕЛЬ:');
define('ENTRY_SHIP_TO', 'АДРЕС ДОСТАВКИ:');
define('ENTRY_PAYMENT_METHOD', 'Способ Оплаты:');

