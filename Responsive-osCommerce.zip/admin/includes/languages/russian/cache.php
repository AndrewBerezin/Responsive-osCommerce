<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Управление Кэшем');

define('TABLE_HEADING_CACHE', 'Блоки');
define('TABLE_HEADING_DATE_CREATED', 'Дата создания');
define('TABLE_HEADING_ACTION', 'Действие');

define('TEXT_FILE_DOES_NOT_EXIST', 'Файл отсутствует');
define('TEXT_CACHE_DIRECTORY', 'Кэш директория:');

define('ERROR_CACHE_DIRECTORY_DOES_NOT_EXIST', 'Ошибка: Кэш директория отсутствует. Установите в Настройки->Кэш.');
define('ERROR_CACHE_DIRECTORY_NOT_WRITEABLE', 'Ошибка: Кэш директория имеет неверные права доступа.');

