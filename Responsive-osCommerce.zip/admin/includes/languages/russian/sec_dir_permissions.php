<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Проверка прав доступа директорий');

define('TABLE_HEADING_DIRECTORIES', 'Директория');
define('TABLE_HEADING_WRITABLE', 'Доступна на записть');
define('TABLE_HEADING_RECOMMENDED', 'Рекомендации');

define('TEXT_DIRECTORY', 'Директория:');
?>