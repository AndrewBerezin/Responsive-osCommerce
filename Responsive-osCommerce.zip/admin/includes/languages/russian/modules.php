<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2008 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_MODULES', 'Модули');
define('TABLE_HEADING_SORT_ORDER', 'Порядок Сортировки');
define('TABLE_HEADING_ACTION', 'Действие');

define('TEXT_INFO_VERSION', 'Версия:');
define('TEXT_INFO_ONLINE_STATUS', 'включён');
define('TEXT_INFO_API_VERSION', 'Версия API:');

define('TEXT_MODULE_DIRECTORY', 'Директория Модулей:');