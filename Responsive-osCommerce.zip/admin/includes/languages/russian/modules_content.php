<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Модули Содержимого');

define('TABLE_HEADING_MODULES', 'Модули');
define('TABLE_HEADING_GROUP', 'Группа');
define('TABLE_HEADING_SORT_ORDER', 'Сортировка');
define('TABLE_HEADING_ACTION', 'Действие');

define('TEXT_INFO_VERSION', 'Версия:');
define('TEXT_INFO_ONLINE_STATUS', 'статус онлайн');
define('TEXT_INFO_API_VERSION', 'Версия API:');

define('TEXT_MODULE_DIRECTORY', 'Директория модуля:');