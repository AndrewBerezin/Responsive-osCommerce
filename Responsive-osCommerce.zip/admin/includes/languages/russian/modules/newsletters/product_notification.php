<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_COUNT_CUSTOMERS', 'Покупатели, получающие рассылку: %s');
define('TEXT_PRODUCTS', 'Товары');
define('TEXT_SELECTED_PRODUCTS', 'Выбранные Товары');

define('JS_PLEASE_SELECT_PRODUCTS', 'Пожалуйста, выберите товары.');

define('BUTTON_GLOBAL', 'Глобально');
define('BUTTON_SELECT', '>>>');
define('BUTTON_UNSELECT', '<<<');
define('BUTTON_SUBMIT', 'Подтвердить');
define('BUTTON_CANCEL', 'Отмена');
