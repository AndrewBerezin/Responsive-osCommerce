<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_ORDERS_TITLE', 'Заказы');
define('MODULE_ADMIN_DASHBOARD_ORDERS_DESCRIPTION', 'Показать последние заказы');
define('MODULE_ADMIN_DASHBOARD_ORDERS_TOTAL', 'Итого');
define('MODULE_ADMIN_DASHBOARD_ORDERS_DATE', 'Дата');
define('MODULE_ADMIN_DASHBOARD_ORDERS_ORDER_STATUS', 'Статус');
?>