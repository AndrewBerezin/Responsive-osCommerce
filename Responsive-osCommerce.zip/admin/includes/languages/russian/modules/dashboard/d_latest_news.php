<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_TITLE', 'Последние новости');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_DESCRIPTION', 'Показать последние новости osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_DATE', 'Дата');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_FEED_ERROR', 'Не могу подключиться к новсотному фиду osCommerce. Следующая попытка будет осуществлена в течении 24 часов.');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_NEWS', 'Читать последние новости osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_NEWSLETTER', 'Подключиться к новостям osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_GOOGLE_PLUS', 'Круг osCommerce на Google+');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_FACEBOOK', 'Подключитьс к osCommerce в Facebook');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_TWITTER', 'Следовать за osCommerce на Twitter');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_RSS', 'Подписаться на RSS фид новостей osCommerce');
