<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_PARTNER_NEWS_TITLE', 'Новости партнёра');
define('MODULE_ADMIN_DASHBOARD_PARTNER_NEWS_DESCRIPTION', 'Посмотреть последние новости пратнёра osCommerce');
define('MODULE_ADMIN_DASHBOARD_PARTNER_NEWS_MORE_TITLE', 'Посмотреть остальные партнёрские сервисы');
define('MODULE_ADMIN_DASHBOARD_PARTNER_NEWS_ERROR_JSON_DECODE', 'Требуется функция PHP json_decode().');

