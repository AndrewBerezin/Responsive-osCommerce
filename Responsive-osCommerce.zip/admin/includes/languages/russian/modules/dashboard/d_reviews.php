<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_REVIEWS_TITLE', 'Отзывы');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_DESCRIPTION', 'Показать последние отзывы');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEWER', 'Автор');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_DATE', 'Дата');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_RATING', 'Рейтинг');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEW_STATUS', 'Статус');
?>