<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_TOTAL_REVENUE_TITLE', 'Диаграмма выручки (последние 30 дней)');
define('MODULE_ADMIN_DASHBOARD_TOTAL_REVENUE_DESCRIPTION', 'Показать диаграмму выручки за последние 30 дней');
define('MODULE_ADMIN_DASHBOARD_TOTAL_REVENUE_CHART_LINK', 'Выручка итого');
?>