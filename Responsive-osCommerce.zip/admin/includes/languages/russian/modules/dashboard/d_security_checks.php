<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_TITLE', 'Проверка безопасности');
define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_DESCRIPTION', 'Запустить проверку безопасности');
define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_SUCCESS', 'Данная установка интернет-магазина osCommerce правильно сконфигурирована!');
?>