<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_TITLE', 'Последие дополнительные модули');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_DESCRIPTION', 'Показать последние дополнительные модули osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_DATE', 'Дата');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_FEED_ERROR', 'Не получается подключиться к фиду  дополнительные модули osCommerce. Следующая попытка будет осуществлена в течение 24 часов.');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_ICON_SITE', 'Перейти на сайт дополнительных модулей osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_ICON_RSS', 'Подписаться на RSS-фид дополнительных модулей osCommerce');
