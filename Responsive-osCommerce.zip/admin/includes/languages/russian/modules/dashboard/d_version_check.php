<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_TITLE', 'Проверка версии');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DESCRIPTION', 'Показать результаты проверки версии');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DATE', 'Последний раз проверялась');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_CHECK_NOW', 'Проверить сейчас');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_NEVER', 'Никогда');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_UPDATE_AVAILABLE', 'Доступна обновлённая версия osCommerce Online Merchant!');
?>