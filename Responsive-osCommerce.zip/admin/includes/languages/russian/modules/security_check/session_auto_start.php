<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_SESSION_AUTO_START', 'Установлен параметр session.auto_start - необходимо выключить его в php.ini и рестартовать веб-сервер. На некоторых серверах выключить данный параметр можно в .htaccess.');
?>