<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('ERROR_NO_DEFAULT_LANGUAGE_DEFINED', 'Ошибка: Не определён язык по уиолчанию. Пожалуйста установите его на: Инструменты администратора->Локализация->Языки');
?>