<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_CONFIG_FILE_WRITEABLE', 'Файл: ' . DIR_FS_CATALOG . 'includes/configure.php доступен на запись. Это потеннциальная угроза безопасности - исправьте пожалуйста права доступа к файлу.');
?>