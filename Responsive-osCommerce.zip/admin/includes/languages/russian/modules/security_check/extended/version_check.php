<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_VERSION_CHECK_TITLE', 'Проверка Версии');
define('MODULE_SECURITY_CHECK_EXTENDED_VERSION_CHECK_ERROR', 'Проверка новой версии запускалась более 30 дней назад. Запустите проверку Версии.');

