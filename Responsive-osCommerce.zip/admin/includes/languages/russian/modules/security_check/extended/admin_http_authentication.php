<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_HTTP_AUTHENTICATION_TITLE', 'HTTP-Индентификация Админа');
define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_HTTP_AUTHENTICATION_ERROR', 'HTTP-Индентификация не была создана для Админа - пожалуйста, установите HTTP-Индентификацию в конфигурации веб-сервера для защиты Админа от несанкционированного доступа.');