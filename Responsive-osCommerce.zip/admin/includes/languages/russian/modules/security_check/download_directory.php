<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_DOWNLOAD_DIRECTORY_NON_EXISTENT', 'Отсутствует директория загружаемых товаров: ' . DIR_FS_DOWNLOAD . '. Загружаемые товары не будут работать до тех пор, пока эта директорию не будет создана.');
?>