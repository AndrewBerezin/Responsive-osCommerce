<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_LAST_RUN_OLD', 'Прошло более 30 дней с последнего запуска Проверки Безопасности. Пожалуйста запустите Проверку Безопасности из меню Инструменты -&gt; Проверка Безопасности.');

