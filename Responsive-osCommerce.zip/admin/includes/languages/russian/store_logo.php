<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Логотип магазина');

define('TEXT_LOGO_IMAGE', 'Новый логотип:');
define('TEXT_FORMAT_AND_LOCATION', 'Логотип магазина должен быть в формате PNG и будет сохранено в:');

define('SUCCESS_LOGO_UPDATED', 'Успешно: Логотип магазина успешно обновлён!');

define('ERROR_IMAGES_DIRECTORY_NOT_WRITEABLE', 'Ошибка: Невозаможно загрузить файл в директорию картинок. (<a href="%s">кликните для просмотра параметров достпа директорий</a>)');
?>