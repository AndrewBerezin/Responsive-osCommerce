<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_EXT_DIRECTORY_LISTING_TITLE', 'ext/ Directory Listing');
define('MODULE_SECURITY_CHECK_EXTENDED_EXT_DIRECTORY_LISTING_HTTP_200', 'The <a href="' . tep_catalog_href_link('ext/') . '" target="_blank">' . DIR_WS_CATALOG . 'ext/</a> directory is publicly accessible and/or browsable - please disable directory listing for this directory in your web server configuration.');
?>
