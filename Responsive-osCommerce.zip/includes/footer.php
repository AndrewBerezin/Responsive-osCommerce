<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

?>

</div>

<footer>
  <div class="footer">
    <div class="<?php echo BOOTSTRAP_CONTAINER; ?>">
      <div class="row">
        <?php echo $oscTemplate->getContent('footer'); ?>
      </div>
    </div>
  </div>
  <div class="footer-extra">
    <div class="<?php echo BOOTSTRAP_CONTAINER; ?>">
      <div class="row">
        <?php echo $oscTemplate->getContent('footer_suffix'); ?>
      </div>
    </div>
  </div>
</footer>

